package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"strings"

	"github.com/function61/gokit/os/osutil"
	"github.com/joonas-fi/midi/pkg/mpkminimk3"
	"github.com/spf13/cobra"
	"gitlab.com/gomidi/midi"
	"gitlab.com/gomidi/midi/midimessage/sysex"
	"gitlab.com/gomidi/midi/reader"
	driver "gitlab.com/gomidi/rtmididrv"
)

func akaiSendSettings(ctx context.Context) error {
	drv, err := driver.New()
	if err != nil {
		return err
	}

	return akaiSendSettingsWithDriver(ctx, drv)
}

func akaiSendSettingsWithDriver(ctx context.Context, drv midi.Driver) error {
	midiOut, err := func() (midi.Out, error) {
		outputs, err := drv.Outs()
		if err != nil {
			return nil, err
		}

		for _, output := range outputs {
			if strings.HasPrefix(output.String(), dev) {
				return output, output.Open()
			}
		}

		return nil, errors.New("not found")
	}()
	if err != nil {
		return err
	}
	defer midiOut.Close()

	msg, err := mpkminimk3.CustomSettings(
		"Hautomo",
		10, // channel for pads TODO: this is -1 for some reason. we actually mean 9
		mpkminimk3.AutopopulatePads(36),
		mpkminimk3.AutopopulatePads(36), // TODO
		1,                               // channel for keys and knobs TODO: is this 1 or 0?
		mpkminimk3.KnobAbsolute0to127("KNOB 1", 70), // "K1"
		mpkminimk3.KnobAbsolute0to127("KNOB 2", 71),
		mpkminimk3.KnobRelative("i3 panel width", 72), // "K3"
		mpkminimk3.KnobAbsolute0to127("KNOB 4", 73),
		mpkminimk3.KnobAbsolute0to127("KNOB 5", 74),
		mpkminimk3.KnobAbsolute0to127("Sublime cols", 75),
		mpkminimk3.KnobRelative("i3 panel height", 76),
		mpkminimk3.KnobRelative("Volume", 77), // "K8"
	).SysExStore(mpkminimk3.ProgramRAM)

	if _, err := midiOut.Write(msg); err != nil {
		return fmt.Errorf("error sending msg: %w", err)
	}

	return err
}

func akaiEntry() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "akai",
		Short: "",
		Args:  cobra.NoArgs,
		Run: func(cmd *cobra.Command, args []string) {
			osutil.ExitIfError(akai(
				osutil.CancelOnInterruptOrTerminate(nil)))
		},
	}

	cmd.AddCommand(&cobra.Command{
		Use:   "send-settings",
		Short: "Send Hautomo settings to AKAI's RAM",
		Args:  cobra.NoArgs,
		Run: func(cmd *cobra.Command, args []string) {
			osutil.ExitIfError(akaiSendSettings(
				osutil.CancelOnInterruptOrTerminate(nil)))
		},
	})

	return cmd
}

func akai(ctx context.Context) error {
	drv, err := driver.New()
	if err != nil {
		return err
	}

	// make sure to close all open ports at the end
	defer drv.Close()

	in, err := midi.OpenIn(drv, -1, dev)
	if err != nil {
		return err
	}
	defer in.Close()

	out, err := midi.OpenOut(drv, -1, dev)
	if err != nil {
		return err
	}
	defer out.Close()

	/*
		if err := in.SetListener(func(data []byte, deltaMicroseconds int64) {
			log.Printf("MIDI inbound: %x", data)
		}); err != nil {
			return fmt.Errorf("SetListener: %w", err)
		}
	*/

	rd := reader.New(
		reader.NoLogger(),
		/*
			reader.SysEx(func(_ *reader.Position, data []byte) {
				log.Printf("MIDI inbound: %x", data)
			}),
		*/
		reader.Each(func(pos *reader.Position, msgGeneric midi.Message) {
			switch msg := msgGeneric.(type) {
			case sysex.SysEx:
				// dada does not contain header and footer, but does contain manufacturer byte!
				log.Printf("sysex %x", msg.Data())
			default:
				log.Printf("other MIDI message: %s", msgGeneric.String())
			}
		}),
	)

	if err := rd.ListenTo(in); err != nil {
		return err
	}

	// msg := requestConfigMsg()
	msg, err := mpkminimk3.ExampleSettings().SysExStore(mpkminimk3.Program8)
	if err != nil {
		return err
	}

	if _, err := out.Write(msg); err != nil {
		return fmt.Errorf("error sending msg: %w", err)
	}

	<-ctx.Done()

	return nil
}

/*
const (
	SNDRV_SEQ_IOCTL_PVERSION 0x40045300
	SNDRV_SEQ_IOCTL_CLIENT_ID 0x40045301
)

func akaiReceive(ctx context.Context)error{
	seq,err:=os.Open("/dev/snd/seq")
	if err!=nil{
		return
	}

	unix.IoctlSetInt(seq.Fd(),SNDRV_SEQ_IOCTL_PVERSION,)
openat(AT_FDCWD, "/dev/snd/seq", O_RDWR|O_CLOEXEC) = 3
ioctl(3, SNDRV_SEQ_IOCTL_PVERSION, 0x7fff9ca90fc8) = 0
ioctl(3, SNDRV_SEQ_IOCTL_CLIENT_ID, 0x7fff9ca90fcc) = 0
ioctl(3, SNDRV_SEQ_IOCTL_RUNNING_MODE, 0x7fff9ca90fd0) = 0
ioctl(3, SNDRV_SEQ_IOCTL_GET_CLIENT_INFO, 0x7fff9ca91290) = 0
ioctl(3, SNDRV_SEQ_IOCTL_SET_CLIENT_INFO, 0x7fff9ca91290) = 0
ioctl(3, SNDRV_SEQ_IOCTL_CREATE_PORT, 0x7fff9ca912a0) = 0
ioctl(3, SNDRV_SEQ_IOCTL_SUBSCRIBE_PORT, 0x7fff9ca91300) = 0
fcntl(3, F_GETFL)                       = 0x8002 (flags O_RDWR|O_LARGEFILE)
fcntl(3, F_SETFL, O_RDWR|O_NONBLOCK|O_LARGEFILE) = 0
}
*/
